'use client'

import Link from 'next/link'
import { Ico, type Icono } from './iconos'
import { useCasa } from './actividades-contexto'

/*
  La barra de abajo.

  Cinco pestañas y las cinco son secciones de verdad: nada escondido
  detrás de tres puntos. Los ajustes salen de la inicial de arriba,
  que es donde todo el mundo los busca.

  Encima, el botón de voz: pequeño, siempre en el mismo sitio, pegado
  a la barra. Solo el símbolo de onda.

  Está a 52 px y a diez del borde de la barra. Estaba a 58 y flotando
  72 px por encima, y ahí molestaba dos veces: tapaba el final de las
  listas y obligaba a dejarle un hueco a la derecha en pantallas donde
  no pintaba nada —el pie del calendario tenía un `pr-24` puesto solo
  para esquivarlo, que partía la leyenda en dos renglones—.

  52 px sigue por encima de los 48 que fijamos como mínimo para lo que
  hay que pulsar. Por debajo de eso no baja aunque quede más elegante.

  En Inicio no aparece: allí la invitación de arriba ya lleva el mismo
  símbolo, y dos botones para lo mismo en una pantalla es uno de más.
*/

type Seccion = string | null

/*
  ═══════════════════════════════════════════════════════════════
  CINCO PESTAÑAS FIJAS · Fase 2
  ═══════════════════════════════════════════════════════════════

      Inicio · Papeles · Agenda · Cuentas · El día a día

  Cinco es el tope de verdad: con seis, cada botón baja de los 48 px
  que protegen a un dedo de 75 años, y ese suelo no se negocia por
  hacer sitio a una sección.

  ─────────────────────────────────────────────────────────────
  LO QUE HABÍA, Y POR QUÉ NO PODÍA QUEDARSE

  La barra era ésta:

      Inicio · Papeles · Agenda · Finca · Helechos

  Tres funciones y dos NOMBRES PROPIOS. En esta casa son la Finca y
  Los Helechos; en la de al lado serán «Alquileres» y «Obra del
  garaje». O sea: la barra no tenía una forma fija, así que no se
  podía aprender — y explicársela a alguien por teléfono era imposible
  porque en su móvil ponía otra cosa.

  Y arrastraba un problema mayor. Con esas dos ocupando sitio, NO
  QUEDABA HUECO para nada más, así que La compra, los Menús, las
  Notas, La casa y el asesor colgaban todos del Inicio. Por eso Inicio
  medía mil doscientas líneas y había que bajar media pantalla para
  llegar al médico de las diez.

  No eran dos problemas: era uno. El sitio de las actividades en la
  barra era el sitio que le faltaba al día a día.

  ─────────────────────────────────────────────────────────────
  LO QUE CUESTA, DICHO CLARO

  Quien tiene una o dos actividades y las abre a diario paga UN TOQUE
  MÁS: antes la Finca estaba abajo, ahora está dentro de Cuentas.

  Se acepta porque a cambio la barra es igual en todas las casas, no
  cambia de forma cuando alguien crea una actividad nueva, y el día a
  día —que se usa varias veces al día, no una vez a la semana— pasa a
  estar a un toque en vez de a un scroll.
*/
type Pestana = { clave: string; texto: string; icono: Icono; href: string }

const INICIO:   Pestana = { clave: 'inicio',     texto: 'Inicio',  icono: 'casa',       href: '/' }
const PAPELES:  Pestana = { clave: 'documentos', texto: 'Papeles', icono: 'carpeta',    href: '/documentos' }
const AGENDA:   Pestana = { clave: 'agenda',     texto: 'Agenda',  icono: 'calendario', href: '/agenda' }
const CUENTAS:  Pestana = { clave: 'cuentas',    texto: 'Cuentas', icono: 'euro',       href: '/cuentas' }
/*
  «Día a día» y no «El día a día»: a 360 px la barra reparte 72 px por
  botón, y el rótulo va a 12 px. «El día a día» se parte en dos
  renglones y descuadra las otras cuatro. Dentro, la pantalla sí se
  llama por su nombre entero.
*/
const DIA_A_DIA: Pestana = { clave: 'dia', texto: 'Día a día', icono: 'taza', href: '/dia' }


/*
  ═══════════════════════════════════════════════════════════════
  Y LA BARRA NO ES LA MISMA PARA TODOS
  ═══════════════════════════════════════════════════════════════

  Hasta ahora sí lo era, y quedaba mal en cuanto entraba alguien que
  no es de la familia. A quien ayuda en casa le salían Papeles y las
  actividades: la base de datos le vaciaba el contenido —eso funciona—
  pero se pasaba el día viendo dos pestañas que no llevan a nada. Y
  una pestaña vacía no se lee como «esto no es para ti»: se lee como
  «esto está roto».

  Cada uno ve las suyas, y de paso le caben más anchas:

    Ayuda en casa   Inicio · Agenda · La compra
    Asesor          Inicio · Papeles · sus actividades
    Familia         todo, como siempre

  ESTO NO PROTEGE NADA, y conviene repetirlo. Quitar la pestaña de
  Papeles no impide abrir `/documentos` escribiéndolo — eso lo impiden
  las políticas de la base de datos. Aquí solo se decide qué se
  ofrece: no esconder, sino que cada uno encuentre lo suyo.
*/
export default function Barra({
  activa = null,
  voz = true,
}: {
  activa?: Seccion
  voz?: boolean
}) {
  const { rol } = useCasa()

  /* La voz sirve para APUNTAR y para preguntar. A quien no puede
     escribir nada —el asesor, quien solo mira— le daría un botón
     grande que falla en cuanto lo use. */
  const puedeHablar = rol !== 'asesor' && rol !== 'mirar'

  /*
    ── Y LA BARRA NO ES LA MISMA PARA TODOS ──

    Cada papel ve las suyas, y de paso le caben más anchas. Con la
    barra fija esto se simplifica: ya no hay que calcular nada, solo
    quitar lo que a esa persona no le lleva a ningún sitio.

      Ayuda en casa   Inicio · Agenda · Día a día
      Asesor          Inicio · Papeles · Agenda · Cuentas
      Familia         las cinco

    A quien ayuda en casa se le quitan Papeles y Cuentas: la base de
    datos se los vacía —eso funciona— pero pasarse el día viendo dos
    pestañas que no llevan a nada no se lee como «esto no es para ti»,
    se lee como «esto está roto». Y el Día a día se le queda porque es
    literalmente su pantalla: ahí están la compra, los menús y lo que
    toca hoy.

    Al asesor se le quita el Día a día por lo mismo: la compra y los
    recados de una familia que no es la suya no le corresponden. La
    agenda sí, porque desde que puede poner fechas es donde hace su
    trabajo — «el día 20 hay un pago» va en un calendario, no en un
    WhatsApp.
  */
  const PESTANAS: Pestana[] =
    rol === 'ayuda'
      ? [INICIO, AGENDA, DIA_A_DIA]
      : rol === 'asesor'
        ? [INICIO, PAPELES, AGENDA, CUENTAS]
        : [INICIO, PAPELES, AGENDA, CUENTAS, DIA_A_DIA]

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40">
      <div className="pointer-events-none relative mx-auto max-w-md">
        {voz && puedeHablar && (
          <Link
            href="/hablar"
            aria-label="Hablar con HUBI"
            className="pointer-events-auto absolute bottom-[10px] right-4 flex flex-col items-center"
          >
            <span className="relative flex h-[52px] w-[52px] items-center justify-center">
              <span className="pulso" />
              <span className="pulso pulso-b" />
              <span
                className="relative flex h-[52px] w-[52px] items-center justify-center rounded-full text-white"
                style={{
                  background: 'linear-gradient(140deg,#2DD4BF,#14B8A6 45%,#3B82F6)',
                  boxShadow:
                    '0 10px 26px rgba(20,184,166,.45), inset 0 1px 0 rgba(255,255,255,.35)',
                }}
              >
                <Ico nombre="onda" tam={23} grosor={2.4} />
              </span>
            </span>
          </Link>
        )}
      </div>

      <nav
        className="barra-abajo pointer-events-auto border-t border-borde bg-superficie"
        style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      >
        <div className="mx-auto flex h-[68px] max-w-md">
          {PESTANAS.map((p) => {
            const puesta = p.clave === activa
            return (
              <Link
                key={p.clave}
                href={p.href}
                prefetch={false}
                aria-current={puesta ? 'page' : undefined}
                /*
                  La pestaña en la que estás va en TINTA, no en verde.

                  Es la misma regla que la píldora del sistema: estar
                  en un sitio es un ESTADO, no una acción. Y el verde
                  ya no es un acento — es el color de ámbito de la
                  Finca, así que la pestaña activa iba pintada del
                  color de una sección concreta.
                */
                className={`flex flex-1 flex-col items-center justify-center gap-1 text-[12px] font-bold ${
                  puesta ? 'text-tinta' : 'text-apagado'
                }`}
              >
                <Ico nombre={p.icono} tam={25} grosor={puesta ? 2.1 : 1.9} />
                <span>{p.texto}</span>
              </Link>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
