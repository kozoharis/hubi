'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import HubiInput, { type EstadoHubi } from './hubi-input'
import { esUnaOrden } from '@/lib/entender-voz'

/*
  ═══════════════════════════════════════════════════════════════
  LA CAJA DE HUBI, CONECTADA
  ═══════════════════════════════════════════════════════════════

  `hubi-input.tsx` era la pieza —los estados, el degradado, el
  medidor— definida en Fase 1 y sin usar. Esto es lo que la enchufa.

  ─────────────────────────────────────────────────────────────
  LO QUE ARREGLA

  En Papeles había un buscador —«¿Qué estás buscando?»— y en la barra
  un botón de voz. Dos cajas que hacen la MISMA pregunta con dos
  motores distintos, y la persona teniendo que saber a cuál acudir.
  Eso es exactamente lo contrario de «no busques, pregunta a HUBI».

  Ahora es una. Escribes lo que sea y HUBI decide qué era.

  ─────────────────────────────────────────────────────────────
  Y DECIDE AQUÍ, GRATIS, SIN LLAMAR A NADIE

  `esUnaOrden()` corre en el propio móvil: son expresiones regulares,
  no un modelo. Así que escribir «facturas agua 2026» busca al
  instante, igual que antes — no hay ni un viaje de más ni un céntimo
  de más por haber puesto a HUBI en medio.

  Solo cuando hay una señal de que es una ORDEN o una PREGUNTA se va a
  `/hablar`, que es donde vive la confirmación de siempre.

  ─────────────────────────────────────────────────────────────
  ANTE LA DUDA, SE BUSCA

  Y es la regla que hace que esto se pueda soltar en una pantalla que
  antes era un buscador: buscar es instantáneo, gratis y NO CAMBIA
  NADA. Apuntar sí. Si HUBI se equivoca hacia buscar, te salen unos
  papeles y vuelves a escribir; si se equivoca hacia apuntar, te deja
  una tarea inventada en la agenda que hay que ir a borrar.
*/
export default function HubiCaja({
  donde,
  valor = '',
  /** A dónde va una búsqueda desde esta pantalla. */
  buscarEn = '/documentos',
  rotando,
}: {
  donde: string
  valor?: string
  buscarEn?: string
  /*
    Frases que se van turnando en el hueco del campo. Solo en el
    Inicio: es donde alguien mira sin saber todavía qué se puede
    pedir. Dentro de Papeles la sugerencia es fija, porque ahí ya
    sabes a qué has ido.
  */
  rotando?: string[]
}) {
  const router = useRouter()
  const [texto, setTexto] = useState(valor)
  const [estado, setEstado] = useState<EstadoHubi>('reposo')
  const [cual, setCual] = useState(0)

  /* Se para en cuanto hay algo escrito: una frase que cambia sola
     debajo de lo que estás escribiendo es de las cosas que más
     despistan, y aquí no hay ninguna prisa por enseñar la siguiente. */
  const quieto = texto.trim().length > 0
  useEffect(() => {
    if (!rotando || rotando.length < 2 || quieto) return
    const t = setTimeout(() => setCual((n) => (n + 1) % rotando.length), 4200)
    return () => clearTimeout(t)
  }, [rotando, cual, quieto])

  function enviar() {
    const t = texto.trim()
    if (!t) return

    setEstado('pensando')

    if (esUnaOrden(t)) {
      /* `/hablar` ya sabe recibir una frase escrita: es el mismo
         camino que usa el Atajo de Siri. No hay un segundo intérprete
         ni una segunda pantalla de confirmación. */
      router.push(`/hablar?dicho=${encodeURIComponent(t)}`)
    } else {
      router.push(`${buscarEn}?q=${encodeURIComponent(t)}`)
    }
  }

  return (
    <HubiInput
      donde={donde}
      sugerencia={rotando && !quieto ? rotando[cual] : undefined}
      estado={estado}
      valor={texto}
      alEscribir={setTexto}
      alEnviar={enviar}
      /* Hablar SÍ se lleva la pantalla entera, y es lo correcto:
         mientras hablas hace falta un blanco grande y una respuesta
         clara de que te está oyendo. La caja es la presencia; hablar
         es el momento. */
      alHablar={() => router.push('/hablar')}
    />
  )
}
